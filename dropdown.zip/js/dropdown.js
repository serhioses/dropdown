;(function () {
    'use strict';

    var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

    window.requestAnimationFrame = requestAnimationFrame;

    Element.prototype.siblings = function () {
        var siblings = [], parentChildren = this.parentNode.children, i;

        for (i = 0; i < parentChildren.length; i++) {
            if (parentChildren[i].nodeType === 1 && parentChildren[i] !== this) {
                siblings.push(parentChildren[i]);
            }
        }

        return siblings;
    };

    Element.prototype.css = function (obj) {
        var prop;

        for (prop in obj) {
            this.style[prop] = obj[prop];
        }

        return this;
    }

    function Dropdown (root, options) {
        var defaults = {
                hideSiblings: true,
                hideOnOtherDropsClick: true,
                hideOutside: true,
                hideNested: true,
                trigger: 'dropdown',
                effect: 'toggle',
                animationDuration: 300
            },
            effects = {
                toggle: function (current, hide) {
                    var triggerClassList = current.trigger.classList,
                        dropdownClassList = current.dropdown.classList;

                    if (hide) {
                        triggerClassList.remove('active');
                        dropdownClassList.remove('opened');
                        dropdownClassList.remove('pressed');
                    } else {
                        triggerClassList.toggle('active');
                        dropdownClassList.toggle('opened');
                        dropdownClassList.toggle('pressed');
                    }

                    return current;
                },
                slide: function (current, hide) {
                    var h, maxHeight, step,
                        triggerClassList = current.trigger.classList,
                        dropdownClassList = current.dropdown.classList;

                    maxHeight = showElement(current.drop);
                    hideElement(current.drop);

                    function innerAnimation (open, timePassed, interval) {
                        if (open) {
                            if (interval === 1) {
                                current.drop.css({
                                    'height': '',
                                    'overflow': ''
                                });

                                return;
                            } else {
                                current.drop.css({
                                    'height': h + 'px',
                                    'overflow': 'hidden'
                                });
                            }

                            step = maxHeight / (defaults.animationDuration / interval);
                            h = h + step;
                            h = +h.toFixed(10);
                        } else {
                            if (interval === 1) {
                                current.drop.css({
                                    'height': '',
                                    'overflow': ''
                                });
                                triggerClassList.remove('active');
                                dropdownClassList.remove('opened');

                                return;
                            } else {
                                current.drop.css({
                                    'overflow': 'hidden',
                                    'height': h + 'px'
                                });
                            }

                            step = maxHeight / (defaults.animationDuration / interval);
                            h = h - step;
                            h = +h.toFixed(10);
                        }
                    }

                    if (dropdownClassList.contains('opened') || hide) {
                        dropdownClassList.remove('pressed');

                        h = maxHeight;
                        current.drop.style.height = maxHeight + 'px';
                        
                        animate(false, innerAnimation, defaults.animationDuration);
                    } else {
                        dropdownClassList.add('pressed');

                        h = 0;

                        current.drop.css({
                            'height': 0,
                            'overflow': 'hidden'
                        });
                        triggerClassList.add('active');
                        dropdownClassList.add('opened');

                        animate(true, innerAnimation, defaults.animationDuration);
                    }
                },
                fade: function (current, hide) {
                    var op, step,
                        triggerClassList = current.trigger.classList,
                        dropdownClassList = current.dropdown.classList;

                    function innerAnimation (open, timePassed, interval) {
                        if (open) {
                            if (interval === 1) {
                                current.drop.style.opacity = '';

                                return;
                            } else {
                                current.drop.style.opacity = op;
                            }

                            step = 1 / (defaults.animationDuration / interval);
                            op = op + step;
                            op = +op.toFixed(10);
                        } else {
                            if (interval === 1) {
                                current.drop.style.opacity = '';

                                triggerClassList.remove('active');
                                dropdownClassList.remove('opened');

                                return;
                            } else {
                                current.drop.style.opacity = op;
                            }

                            step = 1 / (defaults.animationDuration / interval);
                            op = op - step;
                            op = +op.toFixed(10);
                        }
                    }
                    
                    if (dropdownClassList.contains('opened') || hide) {
                        dropdownClassList.remove('pressed');

                        op = 1;
                        current.drop.style.opacity = 1;

                        animate(false, innerAnimation, defaults.animationDuration);
                    } else {
                        dropdownClassList.add('pressed');

                        op = 0;
                        current.drop.style.opacity = 0;

                        triggerClassList.add('active');
                        dropdownClassList.add('opened');

                        animate(true, innerAnimation, defaults.animationDuration);
                    }
                }
            },
            dropdowns = [],
            state = null, COOLDOWN = 1,
            container, containerDropdowns, triggers, len, triggersLength,
            drops, dropsLength,
            isEqual,
            firstDD, siblings, rootDD,
            dropdownsArray, current,
            i;

        function extend (defaults, custom) {
            var prop;

            for (prop in custom) {
                defaults[prop] = custom[prop];
            }

            return defaults;
        }

        function showElement (el) {
            el.css({
                'visibility': 'hidden',
                'display': 'block',
                'position': 'absolute',
                'height': 'auto'
            });

            return el.offsetHeight;
        }

        function hideElement (el) {
            el.css({
                'visibility': '',
                'display': '',
                'position': '',
                'height': ''
            });
        }

        function animate (open, draw, duration) {
            var start = performance.now(),
                prev = start;

            requestAnimationFrame(function anim(time) {
                var timePassed = time - start,
                    interval = (time - prev >= 16) ? Math.abs(time - prev) : 16;

                if (timePassed > duration) {
                    timePassed = duration;
                    interval = 1;
                }

                draw(open, timePassed, interval);

                prev = time;

                if (timePassed < duration) {
                    requestAnimationFrame(anim);
                }
            });
        }

        function filterArray (arr, filter, match) {
            var filtered = [], i;

            for (i = 0; i < arr.length; i++) {
                if (filter(arr[i], match)) {
                    filtered.push(arr[i]);
                }
            }

            return filtered;
        }

        function filterChildren (current, match) {
            var classes = current.className ? current.className.split(' ') : [],
                i;

            for (i = 0; i < classes.length; i++) {
                if (classes[i] === match) {
                    return true;
                }
            }

            return false;
        }

        function createDropdownsArray (arr, id) {
            var tmp = arr.slice(),
                drop, trigger, innerID, parentId, i;

            for (i = 0; i < arr.length; i++) {
                drop = filterArray(tmp[i].children, filterChildren, 'drop');
                trigger = isEqual ? tmp[i] : tmp[i].getElementsByClassName(defaults.trigger)[0];
                innerID = Math.random();
                parentId = (+tmp[i].dataset.level > 1) ? id : null;

                if (drop[0].children) {
                    createDropdownsArray(filterArray(drop[0].children, filterChildren, 'dropdown'), innerID);
                }

                dropdowns.push({
                    dropdown: tmp[i],
                    drop: drop[0],
                    level: tmp[i].dataset.level,
                    trigger: trigger,
                    id: innerID,
                    parentId: parentId
                });
            }

            return dropdowns;
        }

        function hideNested (id) {
            var next = [];

            dropdowns.forEach(function (item) {
                if (item.parentId === id) {
                    if (requestAnimationFrame) {
                        effects[defaults.effect](item, true);
                    } else {
                        effects['toggle'](item, true);
                    }
                    
                    next.push(item);
                }
            });

            if (next.length) {
                next.forEach(function (item) {
                    hideNested(item.id);
                });
            }
        }

        function hideSiblings (current, level) {
            dropdowns.forEach(function (item) {
                if (item !== current && item.level === level) {
                    if (requestAnimationFrame) {
                        effects[defaults.effect](item, true);
                    } else {
                        effects['toggle'](item, true);
                    }
                    
                }
            });

            return current;
        }

        function hideOnOtherDropsClick () {
            var dropdowns = document.querySelectorAll('[data-otherdrops="true"]') || '',
                drop, len = dropdowns.length,
                trigger, arrow, i;

            if (len) {
                for (i = 0; i < len; i++) {
                    if (!isEqual) {
                        arrow = [dropdowns[i].querySelector('.' + defaults.trigger)];
                        trigger = filterArray(arrow, filterChildren, defaults.trigger);
                        trigger[0].classList.remove('active');
                    }

                    drop = dropdowns[i].querySelector('.drop');

                    dropdowns[i].classList.remove('opened', 'active', 'pressed');
                    drop.css({
                        'display': '',
                        'height': '',
                        'overflow': '',
                        'opacity': ''
                    });
                }
            }

            return dropdowns;
        }

        extend(defaults, options);

        container = document.getElementById(root);
        if (!container) {
            throw new Error('The container is not found!');
        }

        containerDropdowns = container.querySelectorAll('.dropdown') || '';
        len = containerDropdowns.length;
        if (!containerDropdowns) {
            throw new Error('The container is empty! It must contain dropdowns!');
        }

        isEqual = (defaults.trigger === 'dropdown') ? true : false;

        if (!isEqual) {
            triggers = container.getElementsByClassName(defaults.trigger) || '';
            triggersLength = triggers.length;
        } else {
            triggers = containerDropdowns;
            triggersLength = len;
        }
        if (!triggers) {
            throw new Error('There are no triggers!');
        }

        drops = container.querySelectorAll('.drop') || '';
        dropsLength = drops.length;
        if (!drops) {
            throw new Error('There are no drops!');
        }

        firstDD = container.querySelector('.dropdown');
        siblings = firstDD.siblings(),
        rootDD = [firstDD].concat(siblings);
        rootDD = filterArray(rootDD, filterChildren, 'dropdown');

        dropdowns = createDropdownsArray(rootDD);

        for (i = 0; i < len; i++) {
            current = containerDropdowns[i];

            if (defaults.hideOutside) {
                current.dataset.outside = 'true';
            }
            if (defaults.hideOnOtherDropsClick) {
                current.dataset.otherdrops = 'true';
            }

            triggers[i].dataset.trigger = 'true';
        }

        this.init = function () {
            var current, i;

            for (i = 0; i < dropdowns.length; i++) {
                dropdowns[i].trigger.addEventListener('click', (function (i) {
                    var current;

                    return function (e) {
                        e.stopPropagation();
                        e.preventDefault();

                        if (defaults.effect !== 'toggle' && requestAnimationFrame) {
                            if (state) {
                                return;
                            }
                        }
                        
                        state = COOLDOWN;
                        current = dropdowns[i];

                        if (requestAnimationFrame) {
                            effects[defaults.effect](current, false);
                        } else {
                            effects['toggle'](current, false);
                        }
                        

                        if (defaults.hideSiblings) {
                            hideSiblings(current, current.level);
                        }
                        if (defaults.hideNested && !current.dropdown.classList.contains('pressed')) {
                            hideNested(current.id);
                        }
                        if (!defaults.hideOnOtherDropsClick) {
                            hideOnOtherDropsClick();
                        }

                        if (defaults.effect !== 'toggle' && requestAnimationFrame) {
                            setTimeout(function () {
                                state = null;
                            }, defaults.animationDuration);
                        }
                    };
                }(i)), false);
            }

            return dropdowns;
        };

        return this;
    }

    window.Dropdown = Dropdown;

    window.addEventListener('load', function () {
        var topNav, sidebarNav, filter, structure;

        topNav = new Dropdown('top-nav', {
            hideOnOtherDropsClick: true,
            hideSiblings: true,
            hideOutside: true,
            trigger: 'trigger',
            hideNested: true,
            effect: 'slide',
            animationDuration: 200
        });
        topNav.init();

        sidebarNav = new Dropdown('sidebar-nav', {
            trigger: 'trigger',
            hideOnOtherDropsClick: false,
            hideSiblings: true,
            hideNested: true,
            hideOutside: false,
            effect: 'slide',
            animationDuration: 300
        });
        sidebarNav.init();

        filter = new Dropdown('filter', {
            trigger: 'trigger',
            hideOnOtherDropsClick: true,
            hideSiblings: true,
            hideNested: true,
            hideOutside: true,
            effect: 'fade',
            animationDuration: 200
        });
        filter.init();

        structure = new Dropdown('structure', {
            trigger: 'trigger',
            hideOnOtherDropsClick: false,
            hideOutside: false,
            animationDuration: 0
        });
        structure.init();

        document.addEventListener('click', function (e) {
            if (!e.target.closest('[data-outside="true"]') && !e.target.closest('.dropdown')) {
                var elements = document.querySelectorAll('[data-outside="true"]'),
                    len = elements.length,
                    drop, el, i;

                for (i = 0; i < len; i++) {
                    drop = elements[i].querySelector('.drop');
                    el = elements[i];

                    el.classList.remove('opened', 'active', 'pressed');

                    drop.css({
                        'display': '',
                        'height': '',
                        'overflow': '',
                        'opacity': ''
                    });

                    if (el.querySelector('[data-trigger="true"]')) {
                        el.querySelector('[data-trigger="true"]').classList.remove('active');
                    }
                }
            }
        }, false);
    });
}());